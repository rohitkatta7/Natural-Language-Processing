# models.py

import numpy as np
import torch
import torch.nn as nn
from torch import optim
import random
from torch.autograd import Variable as Var
import time
import collections

#####################
# MODELS FOR PART 1 #
#####################

class ConsonantVowelClassifier(object):
    def predict(self, context):
        """
        :param context:
        :return: 1 if vowel, 0 if consonant
        """
        raise Exception("Only implemented in subclasses")


class FrequencyBasedClassifier(ConsonantVowelClassifier):
    """
    Classifier based on the last letter before the space. If it has occurred with more consonants than vowels,
    classify as consonant, otherwise as vowel.
    """
    def __init__(self, consonant_counts, vowel_counts):
        self.consonant_counts = consonant_counts
        self.vowel_counts = vowel_counts

    def predict(self, context):
        # Look two back to find the letter before the space
        if self.consonant_counts[context[-1]] > self.vowel_counts[context[-1]]:
            return 0
        else:
            return 1


class RNNClassifier(ConsonantVowelClassifier):
    def __init__(self, model_emb, model_dec, vocab_index):
        self.model_emb = model_emb
        self.model_dec = model_dec
        self.vocab_index = vocab_index

    def predict(self, context):
        x = torch.from_numpy(np.asarray([self.vocab_index.index_of(ci) for ci in context]))
        embedded = self.model_emb.forward(x)
        log_probs = self.model_dec.forward(embedded)
        if log_probs[1] > log_probs[0]:
            return 1
        else:
            return 0


def train_frequency_based_classifier(cons_exs, vowel_exs):
    consonant_counts = collections.Counter()
    vowel_counts = collections.Counter()
    for ex in cons_exs:
        consonant_counts[ex[-1]] += 1
    for ex in vowel_exs:
        vowel_counts[ex[-1]] += 1
    return FrequencyBasedClassifier(consonant_counts, vowel_counts)


def form_ex(str, vocab_indexer):
    idxs = []
    for let in str:
        idxs.append(vocab_indexer.index_of(let))
    result = np.asarray(idxs)
    # print(len(str))
    # print(repr(result))
    return result


def train_classifier(args, train_cons_exs, train_vowel_exs, dev_cons_exs, dev_vowel_exs, vocab_index):
    """
    :param args: command-line args, passed through here for your convenience
    :param train_cons_exs: list of strings followed by consonants
    :param train_vowel_exs: list of strings followed by vowels
    :param dev_cons_exs: list of strings followed by consonants
    :param dev_vowel_exs: list of strings followed by vowels
    :param vocab_index: an Indexer of the character vocabulary (27 characters)
    :return: an RNNClassifier instance trained on the given data
    """
    emb_dim = 20
    hidden_size = 50
    emb_dropout = 0.0
    rnn_dropout = 0.0
    model_emb = EmbeddingLayer(emb_dim, len(vocab_index), emb_dropout)
    model_dec = RNNClassifierModule(emb_dim, hidden_size, rnn_dropout)
    model_parts = [model_emb, model_dec]
    for model in model_parts:
        model.zero_grad()
        model.train()
    optimizer_parts = [optim.Adam(model.parameters(), lr=1e-3) for model in model_parts]

    # cons_indexed = [[vocab_index.index_of(ci) for ci in ex] for ex in cons_exs]
    # vowel_indexed = [[vocab_index.index_of(ci) for ci in ex] for ex in vowel_exs]
    cons_indexed = [[vocab_index.index_of(ci) for ci in ex] for ex in train_cons_exs[0:5000]]
    vowel_indexed = [[vocab_index.index_of(ci) for ci in ex] for ex in train_vowel_exs[0:5000]]

    xs = np.asarray(cons_indexed + vowel_indexed)
    ys = np.asarray([[1, 0] if i < len(cons_indexed) else [0, 1] for i in range(0, len(cons_indexed) + len(vowel_indexed))])
    print(repr(xs.shape))
    print(repr(ys.shape))

    num_epochs = 5
    # num_epochs = 2

    for t in range(0, num_epochs):
        epoch_start = time.time()
        loss_this_epoch = 0.0
        # Train on chunks of 20 chars with burn in of 5
        random.seed(t)
        ex_idxs = [i for i in range(0, len(cons_indexed) + len(vowel_indexed))]
        random.shuffle(ex_idxs)
        loss_fcn = nn.NLLLoss()
        num_done = 0
        for ex_idx in ex_idxs:
            if num_done % 100 == 0:
                print(repr(num_done))
            loss = 0
            input_th = torch.from_numpy(xs[ex_idx])
            output_th = torch.from_numpy(ys[ex_idx]).float()
            # print(repr(input_th))
            embedded = model_emb.forward(input_th)
            # print(repr(embedded))
            log_probs = model_dec.forward(embedded)
            loss += - log_probs.dot(output_th)
            for model in model_parts:
                model.zero_grad()
            loss.backward()
            [optimizer.step() for optimizer in optimizer_parts]
            # optimizer.step()
            loss_this_epoch += loss.item()
            num_done += 1
        print(repr(f"Finished epoch {t} with loss {loss_this_epoch} in time {time.time() - epoch_start}"))
        decoder = RNNClassifier(model_emb, model_dec, vocab_index)
        if t % 10 == 9:
            for model_part in model_parts:
                model_part.eval()
    for model_part in model_parts:
        model_part.eval()
    return decoder




#####################
# MODELS FOR PART 2 #
#####################


class LanguageModel(object):

    def get_next_char_log_probs(self, context) -> np.ndarray:
        """
        Returns a log probability distribution over the next characters given a context.
        The log should be base e
        :param context: a single character to score
        :return: A numpy vector log P(y | context) where y ranges over the output vocabulary.
        """
        raise Exception("Only implemented in subclasses")


    def get_log_prob_sequence(self, next_chars, context) -> float:
        """
        Scores a bunch of characters following context. That is, returns
        log P(nc1, nc2, nc3, ... | context) = log P(nc1 | context) + log P(nc2 | context, nc1), ...
        The log should be base e
        :param next_chars:
        :param context:
        :return: The float probability
        """
        raise Exception("Only implemented in subclasses")


class UniformLanguageModel(LanguageModel):
    def __init__(self, voc_size):
        self.voc_size = voc_size

    def get_next_char_log_probs(self, context):
        return np.ones([self.voc_size]) * np.log(1.0/self.voc_size)

    def get_log_prob_sequence(self, next_chars, context):
        return np.log(1.0/self.voc_size) * len(next_chars)


class RNNLanguageModel(LanguageModel):
    def __init__(self, model_emb, model_dec, vocab_index):
        self.model_emb = model_emb
        self.model_dec = model_dec
        self.vocab_index = vocab_index

    def get_next_char_log_probs(self, context):
        log_probs = []
        curr_state = (torch.from_numpy(np.zeros(self.model_dec.hidden_size)).unsqueeze(0).unsqueeze(1).float(),
                      torch.from_numpy(np.zeros(self.model_dec.hidden_size)).unsqueeze(0).unsqueeze(1).float())
        for char in context:
            embedded = self.model_emb.forward(torch.from_numpy(np.asarray(self.vocab_index.index_of(char))))
            log_probs, hidden = self.model_dec.forward(embedded, curr_state)
            curr_state = hidden
        log_probs = log_probs.squeeze()
        # print(repr(log_probs))
        # print(self.vocab_index.index_of(next_char))
        # print(repr(log_probs))
        # print(repr(log_probs.detach().numpy()))
        return log_probs.detach().numpy()

    def get_log_prob_sequence(self, next_chars, context):
        total_log_prob = 0.0
        for i in range(0, len(next_chars)):
            total_log_prob += self.get_next_char_log_probs(context + next_chars[0:i])[self.vocab_index.index_of(next_chars[i])]
        return total_log_prob


class TransformerLanguageModel(LanguageModel):
    def __init__(self, model_emb, model_dec, vocab_index):
        self.model_emb = model_emb
        self.model_dec = model_dec
        self.vocab_index = vocab_index

    # TODO: Probably remove the ' ' from the beginnings
    def get_next_char_log_probs(self, context):
        # Need to add ' ' to the beginning to agree with log prob sequence
        input = torch.from_numpy(np.asarray([self.vocab_index.index_of(' ')] + [self.vocab_index.index_of(char) for char in context])).type(torch.LongTensor)
        embedded = self.model_emb.forward(input)
        # print(repr(embedded.shape))
        log_probs = self.model_dec.forward(embedded)
        # print(repr(log_probs.shape))
        return log_probs[-1,:].detach().numpy()

    def _get_log_prob_sequence(self, str, idx_to_start):
        # print("GLPS call: [" + str + "], " + repr(idx_to_start))
        loss_fcn = nn.NLLLoss(ignore_index=-1)
        output_indexed = [self.vocab_index.index_of(c) for c in str]
        input = torch.from_numpy(np.asarray([self.vocab_index.index_of(' ')] + output_indexed[0:-1])).type(
            torch.LongTensor)
        # print(repr(input))
        for i in range(0, idx_to_start):
            output_indexed[i] = -1
        output = torch.from_numpy(np.asarray(output_indexed)).type(torch.LongTensor)
        embedded = self.model_emb.forward(input)
        log_probs = self.model_dec.forward(embedded)
        # print("GLPS: " + repr(log_probs))
        loss = -loss_fcn(log_probs, output).item()
        return loss * (len(str) - idx_to_start)

    def get_log_prob_sequence(self, next_chars, context):
        if len(context + next_chars) < 20:
            return self._get_log_prob_sequence(context + next_chars, len(context))
        elif len(context) == 0:
            total_log_prob = 0.0
            chunk_len = 20
            for i in range(0, len(next_chars), chunk_len):
                real_next_chars = next_chars[i:i+chunk_len]
                total_log_prob += self._get_log_prob_sequence(real_next_chars, 0)
            return total_log_prob
        else:
            print("Not really implemented")
            exit()


def train_lm(args, train_text, dev_text, vocab_index):
    print("TRAINING A TRANSFORMER")
    return train_lm_transformer(args, train_text, dev_text, vocab_index)
    # print("TRAINING AN RNN")
    # return train_rnnlm(args, train_text, dev_text, vocab_index)


def train_rnnlm(args, train_text, dev_text, vocab_index):
    """
    :param args: command-line args, passed through here for your convenience
    :param train_text: train text as a sequence of characters
    :param dev_text: dev texts as a sequence of characters
    :param vocab_index: an Indexer of the character vocabulary (27 characters)
    :return: an RNNLanguageModel instance trained on the given data
    """
    emb_dim = 20
    hidden_size = 50
    emb_dropout = 0.0
    rnn_dropout = 0.0
    model_emb = EmbeddingLayer(emb_dim, len(vocab_index), emb_dropout)
    model_dec = RNNDecoder(emb_dim, hidden_size, len(vocab_index), rnn_dropout)
    model_parts = [model_emb, model_dec]
    for model in model_parts:
        model.zero_grad()
        model.train()
    optimizer_parts = [optim.Adam(model.parameters(), lr=1e-3) for model in model_parts]

    burn_in = 0 # ignore this for now
    chunk_len = 20
    batch_starts = [i * (chunk_len - burn_in) for i in range(0, int(len(train_text) / chunk_len))]

    num_epochs = 5
    # num_epochs = 100

    # batch_starts = batch_starts[0:1]

    for t in range(0, num_epochs):
        epoch_start = time.time()
        loss_this_epoch = 0.0
        # Train on chunks of 20 chars with burn in of 5
        random.shuffle(batch_starts)
        num_done = 0
        for batch_idx in batch_starts:
            if num_done % 100 == 0:
                print(repr(num_done))
            # print(repr(batch_idx))
            # print(f"Batch {batch_idx}")
            (input, output) = form_input_output(vocab_index, train_text, batch_idx, chunk_len)
            # loss_fcn = nn.NLLLoss(ignore_index=ignore_index)
            loss_fcn = nn.NLLLoss()
            # print(y_tensor[:,-1])
            # print("LOL")
            loss = 0
            curr_state = (torch.from_numpy(np.zeros(model_dec.hidden_size)).unsqueeze(0).unsqueeze(1).float(),
                          torch.from_numpy(np.zeros(model_dec.hidden_size)).unsqueeze(0).unsqueeze(1).float())
            # TODO: apply the burn-in stuff
            for i in range(0, len(input)):
                input_th = torch.from_numpy(np.asarray(input[i]))
                output_th = torch.from_numpy(np.asarray(output[i]))
                embedded = model_emb.forward(input_th)
                log_probs, hidden = model_dec.forward(embedded, curr_state)
                log_probs = log_probs.squeeze()
                curr_state = hidden
                y_onehot = torch.from_numpy(np.asarray([0 if j != output[i] else 1 for j in range(0, len(vocab_index))])).float()
                # print(log_probs.shape)
                # print(gold_ys.shape)
                # print(repr(log_probs))
                # print(repr(y_onehot))
                # loss = loss_fcn(log_probs, y_onehot)
                loss += - log_probs.dot(y_onehot)
            loss_this_epoch += loss.item() / len(train_text)
            for model in model_parts:
                model.zero_grad()
            loss.backward()
            [optimizer.step() for optimizer in optimizer_parts]
            num_done += 1
            # optimizer.step()
        print(repr(f"Finished epoch {t} with loss {loss_this_epoch} in time {time.time() - epoch_start}"))
        decoder = RNNLanguageModel(model_emb, model_dec, vocab_index)
        if t % 10 == 9:
            for model_part in model_parts:
                model_part.eval()
    for model_part in model_parts:
        model_part.eval()
    return decoder

def form_input_output(vocab_index, text, start_idx, chunk_size):
    raw_words = [vocab_index.index_of(text[i]) for i in range(start_idx, start_idx + chunk_size)]
    output = np.asarray(raw_words)
    input = np.asarray([vocab_index.index_of(' ')] + raw_words[:-1])
    return (input, output)


def train_lm_transformer(args, train_text, dev_text, vocab_index):
    """
    :param args: command-line args, passed through here for your convenience
    :param train_text: train text as a sequence of characters
    :param dev_text: dev texts as a sequence of characters
    :param vocab_index: an Indexer of the character vocabulary (27 characters)
    :return: an RNNLanguageModel instance trained on the given data
    """
    emb_dim = 64
    hidden_size = 64
    emb_dropout = 0.0
    rnn_dropout = 0.0
    model_emb = EmbeddingLayer(emb_dim, len(vocab_index), emb_dropout)
    # model_dec = RNNDecoder(emb_dim, hidden_size, len(vocab_index), rnn_dropout)
    model_dec = TransformerDecoder(emb_dim, hidden_size, len(vocab_index), rnn_dropout)
    model_parts = [model_emb, model_dec]
    for model in model_parts:
        model.zero_grad()
        model.train()
    optimizer_parts = [optim.Adam(model.parameters(), lr=1e-3) for model in model_parts]

    burn_in = 0 # ignore this for now
    chunk_len = 20
    batch_starts = [i * (chunk_len - burn_in) for i in range(0, int(len(train_text) / chunk_len))]

    num_epochs = 5
    # num_epochs = 100

    # batch_starts = batch_starts[0:1]

    for t in range(0, num_epochs):
        epoch_start = time.time()
        loss_this_epoch = 0.0
        # Train on chunks of 20 chars with burn in of 5
        random.shuffle(batch_starts)
        num_done = 0
        for batch_idx in batch_starts:
            if num_done % 100 == 0:
                print(repr(num_done))
            # print(repr(batch_idx))
            # print(f"Batch {batch_idx}")
            (input, output) = form_input_output(vocab_index, train_text, batch_idx, chunk_len)
            loss_fcn = nn.NLLLoss()
            # TODO: does not have any burn-in
            loss = 0
            input_so_far = torch.from_numpy(np.asarray(input))
            output_all = torch.from_numpy(np.asarray(output))
            # output_all_ones = torch.from_numpy(np.asarray([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19])).type(torch.LongTensor)
            embedded = model_emb.forward(input_so_far)
            log_probs = model_dec.forward(embedded)
            loss = loss_fcn(log_probs, output_all) * len(input)
            loss_this_epoch += loss.item() / len(train_text)
            for model in model_parts:
                model.zero_grad()
            loss.backward()
            [optimizer.step() for optimizer in optimizer_parts]
            num_done += 1
            # optimizer.step()
        print(repr(f"Finished epoch {t} with loss {loss_this_epoch} in time {time.time() - epoch_start}"))
        decoder = TransformerLanguageModel(model_emb, model_dec, vocab_index)
        if t % 10 == 9:
            for model_part in model_parts:
                model_part.eval()
    for model_part in model_parts:
        model_part.eval()
    return decoder


# Embedding layer that has a lookup table of symbols that is [full_dict_size x input_dim]. Includes dropout.
# Works for both non-batched and batched inputs
class EmbeddingLayer(nn.Module):
    # Parameters: dimension of the word embeddings, number of words, and the dropout rate to apply
    # (0.2 is often a reasonable value)
    def __init__(self, input_dim, full_dict_size, embedding_dropout_rate):
        super(EmbeddingLayer, self).__init__()
        self.dropout = nn.Dropout(embedding_dropout_rate)
        self.word_embedding = nn.Embedding(full_dict_size, input_dim)

    # Takes either a non-batched input [sent len x input_dim] or a batched input
    # [batch size x sent len x input dim]
    def forward(self, input):
        embedded_words = self.word_embedding(input)
        final_embeddings = self.dropout(embedded_words)
        return final_embeddings


class RNNDecoder(nn.Module):
    def __init__(self, input_size, hidden_size, output_dict_size, dropout, rnn_type='lstm'):
        super(RNNDecoder, self).__init__()
        self.n_layers = 1
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.cell_input_size = input_size
        self.rnn_type = rnn_type
        if rnn_type == 'gru':
            self.rnn = nn.GRU(self.cell_input_size, hidden_size, dropout=dropout)
        elif rnn_type == 'lstm':
            self.rnn = nn.LSTM(self.cell_input_size, hidden_size, num_layers=1, dropout=dropout)
        else:
            raise NotImplementedError
        # output should be batch x output_dict_size
        self.output_layer = nn.Linear(hidden_size, output_dict_size)
        # print(f"Out dict size {output_dict_size}")
        self.log_softmax_layer = nn.LogSoftmax(dim=1)
        self.init_weight()

    def init_weight(self):
        if self.rnn_type == 'lstm':
            nn.init.xavier_uniform_(self.rnn.weight_hh_l0, gain=1)
            nn.init.xavier_uniform_(self.rnn.weight_ih_l0, gain=1)

            nn.init.constant_(self.rnn.bias_hh_l0, 0)
            nn.init.constant_(self.rnn.bias_ih_l0, 0)
        elif self.rnn_type == 'gru':
            nn.init.xavier_uniform_(self.rnn.weight.data, gain=1)

    def forward(self, embedded_input, state):
        # print(ei_reshaped.shape)
        embedded_input = embedded_input.unsqueeze(0).unsqueeze(1)
        # print(repr(embedded_input))
        # print(repr(state))
        hidden_1 = state[0]
        hidden_2 = state[1]
        output, hidden = self.rnn(embedded_input, (hidden_1, hidden_2))
        # print("===========")
        # print(output.shape)
        output = output.squeeze(0)
        # print(output.shape)
        # print(hidden[0].shape)
        logits = self.output_layer.forward(output)
        log_probs = self.log_softmax_layer(logits)
        return log_probs, hidden


class PositionalEncoding(nn.Module):

    def __init__(self, d_model: int, max_len):
        super().__init__()
        self.emb = EmbeddingLayer(d_model, max_len, 0)

    def forward(self, x):
        """
        Args:
            x: Tensor, shape [seq_len, batch_size, embedding_dim]
        """
        to_embed = torch.tensor(np.asarray(range(0, x.size(1)))).type(torch.LongTensor)
        embedded = self.emb(to_embed).unsqueeze(0)
        return x + embedded


class TransformerDecoder(nn.Module):
    def __init__(self, input_size, hidden_size, output_dict_size, dropout):
        super(TransformerDecoder, self).__init__()
        self.n_layers = 1
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.cell_input_size = input_size
        # self.pos_encoder = PositionalEncoding(ninp, dropout)
        # encoder_layers = nn.TransformerEncoderLayer(ninp, nhead, nhid, dropout)
        # self.transformer_encoder = nn.TransformerEncoder(encoder_layers, nlayers)
        # self.transformer = nn.Transformer(d_model=128, nhead=4, num_encoder_layers=6)
        self.pos_encoder = PositionalEncoding(hidden_size, 20)
        encoder_layers = nn.TransformerEncoderLayer(d_model=hidden_size, nhead=4, dim_feedforward=128, batch_first=True)
        # encoder_layers = nn.TransformerDecoderLayer(d_model=hidden_size, nhead=4, dim_feedforward=128, batch_first=True)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layers, num_layers=6)
        # self.transformer_encoder = nn.TransformerDecoder(encoder_layers, num_layers=6)
        # output should be batch x output_dict_size
        self.output_layer = nn.Linear(hidden_size, output_dict_size)
        # print(f"Out dict size {output_dict_size}")
        self.log_softmax_layer = nn.LogSoftmax(dim=1)

    def forward(self, all_embedded_input):
        embedded_input_with_posn = self.pos_encoder(all_embedded_input.unsqueeze(0))
        fake_input_activations = torch.tensor(np.asarray([0.0 for i in range(0, self.hidden_size)])).unsqueeze(0).unsqueeze(0).type(torch.FloatTensor)
        num_toks = embedded_input_with_posn.shape[1]
        tgt_mask = torch.triu(torch.ones(num_toks, num_toks) * float('-inf'), diagonal=1)
        # output = self.transformer_encoder(embedded_input_with_posn, fake_input_activations, tgt_mask=tgt_mask)
        output = self.transformer_encoder(embedded_input_with_posn, mask=tgt_mask)
        output = output.squeeze(0)
        logits = self.output_layer.forward(output)
        log_probs = self.log_softmax_layer(logits)
        return log_probs


############ PART 1

class RNNClassifierModule(nn.Module):
    def __init__(self, input_size, hidden_size, dropout, rnn_type='lstm'):
        super(RNNClassifierModule, self).__init__()
        self.n_layers = 1
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.cell_input_size = input_size
        self.rnn_type = rnn_type
        if rnn_type == 'gru':
            self.rnn = nn.GRU(self.cell_input_size, hidden_size, dropout=dropout)
        elif rnn_type == 'lstm':
            self.rnn = nn.LSTM(self.cell_input_size, hidden_size, num_layers=1, dropout=dropout)
        else:
            raise NotImplementedError
        # output should be batch x output_dict_size
        self.output_layer = nn.Linear(hidden_size, 2)
        # print(f"Out dict size {output_dict_size}")
        self.log_softmax_layer = nn.LogSoftmax(dim=0)
        self.init_weight()

    def init_weight(self):
        if self.rnn_type == 'lstm':
            nn.init.xavier_uniform_(self.rnn.weight_hh_l0, gain=1)
            nn.init.xavier_uniform_(self.rnn.weight_ih_l0, gain=1)

            nn.init.constant_(self.rnn.bias_hh_l0, 0)
            nn.init.constant_(self.rnn.bias_ih_l0, 0)
        elif self.rnn_type == 'gru':
            nn.init.xavier_uniform_(self.rnn.weight.data, gain=1)

    def forward(self, embedded_input):
        # print(ei_reshaped.shape)
        embedded_input = embedded_input.unsqueeze(1)
        # print(repr(embedded_input))
        # print(repr(state))
        init_state = (torch.from_numpy(np.zeros(self.hidden_size)).unsqueeze(0).unsqueeze(1).float(),
                      torch.from_numpy(np.zeros(self.hidden_size)).unsqueeze(0).unsqueeze(1).float())
        output, hidden = self.rnn(embedded_input, init_state)
        # print("===========")
        # print(output.shape)
        # print(hidden)
        # print(output.shape)
        # print(hidden[0].shape)
        logits = self.output_layer.forward(hidden[0].squeeze())
        # print(repr(logits))
        log_probs = self.log_softmax_layer(logits)
        # print(repr(log_probs))
        return log_probs
