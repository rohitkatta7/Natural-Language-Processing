import numpy as np

def viterbi_algorithm(state_space, observation_sequence, initial_probabilities, transition_matrix, emission_matrix):
    num_states = len(state_space)
    num_observations = len(observation_sequence)
    
    viterbi_matrix = np.zeros((num_states, num_observations))
    backtrace_matrix = np.zeros((num_states, num_observations), dtype=int)

    # Initialize the starting probabilities
    viterbi_matrix[:,0] = initial_probabilities * emission_matrix[:,observation_sequence[0]]
    
    # Iterate over the sequence of observations
    for obs_idx in range(1, num_observations):
        for state_idx in range(num_states):
            probability_vector = viterbi_matrix[:,obs_idx-1] * transition_matrix[:,state_idx] * emission_matrix[state_idx, observation_sequence[obs_idx]]
            viterbi_matrix[state_idx, obs_idx] = np.max(probability_vector)
            backtrace_matrix[state_idx, obs_idx] = np.argmax(probability_vector)

    # Backtrack to find the most likely state sequence
    optimal_state_sequence = np.zeros(num_observations, dtype=int)
    optimal_state_sequence[-1] = np.argmax(viterbi_matrix[:,-1])

    for obs_idx in range(num_observations-2, -1, -1):
        optimal_state_sequence[obs_idx] = backtrace_matrix[optimal_state_sequence[obs_idx+1], obs_idx+1]
        
    return optimal_state_sequence, viterbi_matrix

def main():
    pos_tags = ['N', 'M', 'V']
    word_mapping = {
        'Patrick': 0, 'can': 1, 'see': 2, 'Cherry': 3, 'will': 4, 'spot': 5
    }
    initial_probabilities = np.array([0.7, 0.1, 0.2])
    transition_matrix = np.array([
        [0.2, 0.3, 0.5],
        [0.4, 0.1, 0.5],
        [0.8, 0.1, 0.1]
    ])
    emission_matrix = np.array([
        [0.3, 0.1, 0.1, 0.2, 0, 0],
        [0, 0.4, 0, 0, 0.6, 0],
        [0, 0.1, 0.5, 0, 0.2, 0.2]
    ])

    sentence_c = ['Patrick', 'can', 'see', 'Cherry']
    sentence_d = ['will', 'Cherry', 'spot', 'Patrick']

    observation_indices_c = [word_mapping[word] for word in sentence_c]
    observation_indices_d = [word_mapping[word] for word in sentence_d]

    state_sequence_c, viterbi_matrix_c = viterbi_algorithm(pos_tags, observation_indices_c, initial_probabilities, transition_matrix, emission_matrix)
    state_sequence_d, viterbi_matrix_d = viterbi_algorithm(pos_tags, observation_indices_d, initial_probabilities, transition_matrix, emission_matrix)

    print("Most likely tag sequence for 'Patrick can see Cherry':")
    for i, state_idx in enumerate(state_sequence_c):
        print(f"{pos_tags[state_idx]} (probability: {viterbi_matrix_c[state_idx, i]:.10f})")
    
    print("\nMost likely tag sequence for 'will Cherry spot Patrick':")
    for i, state_idx in enumerate(state_sequence_d):
        print(f"{pos_tags[state_idx]} (probability: {viterbi_matrix_d[state_idx, i]:.10f})")

if __name__ == "__main__":
    main()
